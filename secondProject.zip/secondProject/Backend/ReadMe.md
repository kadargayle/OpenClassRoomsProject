# Backend API - Sophie Bluel

This repository contains backend code from architect Sophie Bluel.

## Backend launch

After retrieving the REPO run the `npm install` command to install the project dependencies

Once the dependencies are installed, launch the project with the `npm start` command

Test account for Sophie Bluel
```
email: sophie.bluel@test.tld

password: S0phie 
```
Link to see the
[Swagger documentation ](http://localhost:5678/api-docs/)

To read the documentation, use Chrome or Firefox
