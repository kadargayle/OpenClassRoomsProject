##Instructions to Run the Code

Start the backend from your terminal by following the instructions in the README file.

If you wish to view the backend and frontend code, open them in two separate instances of VSCode to avoid any issues.
